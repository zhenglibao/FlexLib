//___FILEHEADER___

#import <UIKit/UIKit.h>

@interface ___FILEBASENAMEASIDENTIFIER___ : UIViewController

@end


